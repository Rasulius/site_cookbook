<?php
//Модель вывода каталога
 class Application_Models_Catalog
  {	  
	  function getList()
	  { 


		//константы для подключения к базе данных
		 define('HOST', 'localhost'); 		//сервер
		 define('USER', 'root'); 			//пользователь
		 define('PASSWORD', ''); 			//пароль
		 define('NAME_BD', 'LifeExampleShop');		//база
		 $connect = mysqli_connect(HOST, USER, PASSWORD, NAME_BD)or die("Невозможно установить соединение c базой данных".mysql_error( ));
		
		 $sql = "SELECT * FROM recept_chapters";
		 $result = mysqli_query($connect, $sql); 
	
		 while ($row = mysqli_fetch_assoc($result))
		 {		 
			$сatalogItems[]=array(
				"id"=>$row['id'],
				"name"=>$row['name'],
				"description"=>$row['description']
			);
		  }
		
		
		 return $сatalogItems; 
	  }
  } 
?>  
  