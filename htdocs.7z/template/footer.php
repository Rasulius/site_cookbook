
			</div>
			<div id="footer">
			<hr/>
				<em>Все права защищены © 2021 г.</em>
				<br/>
				<em>Шагимарданов Расуль</em>
				<br/>
				<em>e-mail: <a href="mailto:hotgang@mail.ru">hotgang@mail.ru</a></em>
			</div>	
	</div>
	
</body>
</html>