<h1>Весь рецепт</h1>

<!-- a href="/catalog"><<< Назад</a -->
<!-- h1><?=$recipe['name']?></h1>
	<div class="card_product">
		<div class="product_image">
			<image src="/images/<?=$recipe['id']?>.jpg" />
		</div>
		
		<div class="product_desc">
			<?=$recipe['desc']?>					
		</div>
		
		<div class="product_buy">
			<a href="/">Купить</a>
		</div>
	</div -->


<div class="container">
<section>
         <div class="border">
            <div class="wrap">
               <div class="product-wrap">
                  <a href=""><image src="/images/<?=$recipe['id']?>.jpg" /></a>
               </div>
               <div class="loop-action">
                  <a href="" class="add-to-cart">Быстрый просмотр</a>
                  <a href="" class="loop-add-to-cart">В корзину</a>
               </div>
            </div>
            <div class="product-info">
               <div class="stars"></div>
               <h3 class="product-title">Маленькое черное платье</h3>
               <div class="price">&#8381; 1999</div>
            </div>
         </div>
      </section>

</>