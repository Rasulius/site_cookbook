<h1>Каталог</h1>
<?php
//представление каталога (страница каталога)
foreach($Items as $item)
		{
				

if($i%3==0): ?>
			
	<div style="clear:both;"></div>
		<?php endif;?>


	<div class="product">
	   	   
	  <div class="container">
            <section>	
	      <div class="border">
			<div class="product-info">               		
				<h2><?=$item["name"]?></h2>	
			</p>				
			</div>	
	           <div class="wrap">
        	       <div class="product-wrap">
                	  <a href=""><image src="/images/<?=$item["id"]?>.jpg" /></a>
	               </div>
        	
		       <div class="loop-action">
                	  <a href="recipes?type=1" class="add-to-cart">Быстрый просмотр</a>
	                 <!--  <a href="" class="loop-add-to-cart">В корзину</a> -->
               		</div>
	            </div> 	

	           				
              </div>		
	      	            <!--div class="product-info">
               		<div class="stars"></div>
	                <h2> <?//=$item["name"]?></h2>						
	            </div -->
          

		</section>  
	</div>
             </div>
     


	<?php
	$i++;
	
			
			
			
		}
	
?>