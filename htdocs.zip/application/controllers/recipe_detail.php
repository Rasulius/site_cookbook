<?php
//контролер обрабатывает данные каталога
  class Application_Controllers_Recipes_Detail extends Lib_BaseController
  {
     function index()
	 {
	     $model=new Application_Models_Recipes;
		// $Recipes = $model->getRecipes($_REQUEST['type']);	
		 //$this->Recipes=$Recipes;
		 		
	 }
  }

?>